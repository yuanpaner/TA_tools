********************************************************************
Notepad++ Maxscript language definitions

by Ofer Zelichover
www.oferz.com

26/3/2007
You may use and redistribute these files freely.
*********************************************************************

Contents:
userDefineLang.xml  	- the maxscript syntax highlighter definitions.
insertExt.ini  		- the maxscript function list definitions.
maxscript.api 		- maxscript ketwords for the auto-complete feature (using ctrl+space).


Installaion:
1. install notepad++
2. copy the file maxscript.api to C:\Program Files\Notepad++\plugins\ folder
3. copy userDefineLang.xml and insertExt.ini into your %appdata%\notepad++\ folder
  IMPORTANT NOTE!
If you have other user defined languages, you have to edit the userDefineLang.xml file manually
and append the maxscript section from this zip, if you overwrite the file with this version, you'll
lose your previously defined languages!

Happy coding!